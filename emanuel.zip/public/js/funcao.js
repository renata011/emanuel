if($('#mensagem').is(':visible')){
   

    $('#mensagem').fadeOut(8000)
}
