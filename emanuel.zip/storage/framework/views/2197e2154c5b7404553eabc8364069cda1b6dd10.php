<center><H6> VERSÃO TESTE - DESENVOLVIDO POR: PAULO SOARES DE OLIVEIRA - WHATSAPP 51-982974728 </H6></center>

<?php if(!Auth::check()): ?>
	<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<h2> VOCÊ NÃO TEM AUTORIZAÇÃO. FAÇA LOGIN PRIMEIRO </h2>
<?php endif; ?>


<?php if(Auth::check()): ?>
<?php echo $__env->make('layouts/bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form name="cadastro" method="POST" action="<?php echo e(route('salvaCadastro')); ?>">
	<?php echo csrf_field(); ?>
<div class="card-body">
	<center><H6> VERSÃO TESTE - DESENVOLVIDO POR: PAULO SOARES DE OLIVEIRA - WHATSAPP 51-982974728 </H6></center>

	<span id="mensagem"><?php echo e(session('mensagem')); ?></span>
	<div class="row">
		<div class="col-lg-12">
			<span> <input type="text" name="nome" placeholder="Digite o nome do Paciente" class="form-control" title="Digite o nome do Paciente" required="" max="150"></span>
		</div>
		<div class="col-lg-12">
			&nbsp
		</div>
		<div class="col-lg-12">
			<span> <input type="number"  step="1" min="0" name="idade" placeholder="Digite a idade do Paciente" class="form-control" title="Digite a idade do Paciente" max="99999999999" required=""></span>
		</div>
		<div class="col-lg-12">
			&nbsp
		</div>

		<div class="col-lg-12">
			<span> <input type="number" pattern="[0-9]+([.\,][0-9]+)?" step="any" name="peso" placeholder="Digite o peso do Paciente" class="form-control" title="Digite o peso do Paciente" min="0.000" max="999.999" maxlength="7" required=""></span>
		</div>
		<div class="col-lg-12">
			&nbsp
		</div>
		<div class="col-lg-12">
			<span> <input type="number" pattern="[0-9]+([.\,][0-9]+)?" step="any" name="altura" placeholder="Digite a altura do Paciente" class="form-control" title="Digite a altura do Paciente" max="999.99" maxlength="5" required=""></span>
		</div>
		<div class="col-lg-12">
			&nbsp
		</div>
		<div class="col-lg-12">
			<input type="submit" value="Cadastrar" class="btn btn-success form-control">
		</div>
	</div>
</div>
</form>
<hr>
<span> @Copyright  Todos os Direitos Reservados </span>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="<?php echo e(asset('/js/funcao.js')); ?>"></script>
<?php endif; ?><?php /**PATH C:\emanuel\resources\views/paciente/index.blade.php ENDPATH**/ ?>