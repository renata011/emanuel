
<?php echo $__env->make('layouts/bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\emanuel\resources\views/home.blade.php ENDPATH**/ ?>