<center><H6> VERSÃO TESTE - DESENVOLVIDO POR: PAULO SOARES DE OLIVEIRA - WHATSAPP 51-982974728 </H6></center>

<?php if(!Auth::check()): ?>
	<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<h2> VOCÊ NÃO TEM AUTORIZAÇÃO. FAÇA LOGIN PRIMEIRO </h2>
<?php endif; ?>

<?php if(Auth::check()): ?>
 
<?php echo $__env->make('layouts/bootstrap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<table class="table table-responsive">
	<thead>
		<tr>
			<th>NOME PACIENTE</th>
			<th>IDADE</th>
			<th>PESO</th>
			<th>ALTURA</th>

		</tr>
	</thead>
	<tbody>
		<?php $__currentLoopData = $dados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($dado->nome); ?></td>
			<td><?php echo e($dado->idade); ?></td>
			<td><?php echo e($dado->peso); ?></td>
			<td><?php echo e($dado->altura); ?></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>
<?php endif; ?><?php /**PATH C:\emanuel\resources\views/paciente/consulta.blade.php ENDPATH**/ ?>