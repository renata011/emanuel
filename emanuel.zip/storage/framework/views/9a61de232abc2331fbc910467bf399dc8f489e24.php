
	 		<h2> VOCÊ NÃO TEM AUTORIZAÇÃO. FAÇA LOGIN PRIMEIRO </h2>
<?php /**PATH C:\emanuel\resources\views//verifica/index.blade.php ENDPATH**/ ?>